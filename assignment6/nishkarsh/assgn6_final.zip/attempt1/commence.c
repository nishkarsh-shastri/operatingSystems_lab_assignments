#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <sys/shm.h>
#include <sys/time.h>


int main(int argc, char const *argv[])
{
	system("clear");
	printf("COMMENCING CONFERENCE: RESPOND\n");
	return 0;
}